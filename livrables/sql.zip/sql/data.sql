SET NAMES utf8;

INSERT INTO `Ocpizza`.`address`(`name`,`address`,`complement_1`, `postal_code`, `city`)VALUES
("Tom","grand rue","rue",01000,"Bourg-en-Bresse"),
("Alain", "21, rue du chateau", "impasse", 01200, "Lancrans"),
("Claire", "impasse du lieutenant", "miro", 01300, "Belley"),
("Philippe", "le grand chemin", "2eme etage", 01400, "Romans"),
("Pauline", "Trocadero", "16eme", 75016, "Paris16"),
("Charles", "la cote pave", "rdc", 31000, "Toulouse"),
("Louis", "grand chemin", "restau1", 28500, "Luray"),
("Camille", "route barree", "restau2", 45160, "Ardon"),
("Paul", "le bout du chemin", "restau3", 75017, "Paris17"),
("Emilien", "far away", "livreur", 75015, "Paris15");
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`ingredient`(`name`)VALUES
("boeuf"),
("champigon"),
("emmental"),
("jambon"),
("mozzarella"),
("oeuf"),
("oignon"),
("parmesan"),
("olive"),
("origan"),
("pate"),
("poivrons"),
("tomate");
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`pizza`(`name`,`taxe_price`)VALUES
("calzone",6.50),
("caprese",7.00),
("margarita",7.50),
("napolitaine",8.00),
("reine",8.50),
("paysane",8.00);
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`phone`(`number`)VALUES
("0102030401"),
("0602030402"),
("0102030403"),
("0102030404"),
("0602030405"),
("0702030406"),
("0102030407"),
("0102030408"),
("0102030409"),
("0102030410"),
("0102030411"),
("0602030412");
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`restaurant`(`address_id`,`name`,`phone_id`)VALUES
(7,"napoli",6),
(8,"milano",7),
(9,"torino",8);
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`client`(`delivery_address_id`,`phone_id`,`first_name`,`name`,`mail`,`login`,`password`)VALUES
(1,1,"Tom","Tom","tom@mail.fr","Tomtom",UNHEX(SHA2('passtom',256))),
(3,2,"Claire","Long","claire@mail.fr","Clong",UNHEX(SHA2('passclong',256))),
(2,3,"Alain","Ferr","ferr@mail.fr","Leferr",UNHEX(SHA2('passferr',256))),
(6,4,"Charles","Millet","millet@mail.fr","lamil",UNHEX(SHA2('passmill',256))),
(5,5,"Pauline","Ast","ast@mail.fr","Past",UNHEX(SHA2('passpast',256)));
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`employee`(`address_id`,`phone_id`,`first_name`,`name`,`mail`,`login`,`password`)VALUES
(7,9,"Louis","Cust","cust@mail.fr","lcust",UNHEX(SHA2('passcust',256))),
(8,10,"Camille","Richard","cam@mail.fr","camrich",UNHEX(SHA2('passcam',256))),
(9,11,"Paul","Henry","paulo@mail.fr","Phenry",UNHEX(SHA2('passpaulo',256))),
(10,12,"Emilien","Proto","proto@mail.fr","laprot",UNHEX(SHA2('passprot',256)));
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`order`(`employee_id`,`client_id`,`restaurant_id`,`order_num`,`date`,`status`)VALUES
(4,1,2,"18000001","2019-01-29 11:11:11","archive"),
(2,2,1,"18000002","2019-03-30 10:10:10","archive"),
(3,3,1,"18000003","2019-04-30 09:09:09","cancel"),
(4,1,2,"18000004","2019-05-01 05:05:05","deliver"),
(1,5,3,"18000005","2019-06-01 06:06:06","deliver"),
(2,4,1,"18000006","2019-06-01 08:08:08","archive");
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`order_line`(`order_id`,`pizza_id`,`quantity`, `status`)VALUES
(1,5,2, "preparation"),
(1,6,2, "preparation"),
(2,5,1, "waiting"),
(3,1,3, "cancel"),
(4,2,1, "waiting"),
(5,4,2, "preparation"),
(5,3,2, "preparation"),
(6,2,1, "prepared"),
(6,5,3, "prepared");
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`bill`(`payment_type`,`order_id`,`all_taxe_price`,`date`)VALUES
("cash",1,33,"2019-01-29 11:11:11"),
("paypal",2,8.5,"2019-01-30 10:10:10"),
("paypal",3,19.5,"2019-01-31 09:09:09"),
("blue card",4,7,"2019-02-01 05:05:05"),
("blue card",5,31,"2019-02-01 06:06:06"),
("cash",6,32.5,"2019-02-01 08:08:08");
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`(assoc) stock`(`ingredient_id`,`restaurant_id`,`quantity`)VALUES
(1,1,3200),
(2,1,2200),
(3,1,3100),
(4,1,2800),
(5,1,2900),
(6,1,24),
(7,1,3000),
(8,1,2800),
(9,1,2600),
(10,1,3300),
(11,1,3400),
(12,1,2900),
(13,1,3100),
(1,2,3200),
(2,2,0),
(3,2,3100),
(4,2,2800),
(5,2,2900),
(6,2,16),
(7,2,3000),
(8,2,2800),
(9,2,2600),
(10,2,3300),
(11,2,3400),
(12,2,2900),
(13,2,3100),
(1,3,3200),
(2,3,2200),
(3,3,3100),
(4,3,2800),
(5,3,2900),
(6,3,52),
(7,3,3000),
(8,3,2800),
(9,3,2600),
(10,3,3300),
(11,3,3400),
(12,3,2900),
(13,3,3100);
SHOW WARNINGS;

INSERT INTO `Ocpizza`.`(assoc) composition`(`pizza_id`,`ingredient_id`,`quantity`)VALUES
(1,11,1),
(1,4,70),
(1,3,40),
(1,2,70),
(2,11,1),
(2,7,40),
(2,6,1),
(2,5,40),
(3,11,1),
(3,10,60),
(3,9,70),
(3,8,50),
(4,13,60),
(4,12,70),
(4,11,1),
(4,1,40),
(5,11,1),
(5,4,50),
(5,3,60),
(5,2,50),
(6,11,1),
(6,7,15),
(6,6,1),
(6,5,50);
SHOW WARNINGS;

