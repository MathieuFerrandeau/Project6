-- show the status of the order

SELECT order_id, pizza_id, quantity, status FROM order_line WHERE status = "waiting"; -- "preparation" / "cancel" / "prepared"

-- add an order 

INSERT INTO `order` (employee_id, client_id, restaurant_id, order_num, date, status) VALUES (2, 3, 2, "180000007", "2019-07-03 13:07:06", "archive");
INSERT INTO order_line (order_id, pizza_id, quantity, status) VALUES (7, 5, 2, "waiting"); -- insert the order in order_line

-- shows the stock of the selected restaurant

SELECT ingredient.name as ingredients, `(assoc) stock`.quantity as quantity, restaurant.name as restaurant 
FROM `(assoc) stock` 
INNER JOIN ingredient 
    ON `(assoc) stock`.ingredient_id = ingredient.id 
INNER JOIN restaurant 
    ON `(assoc) stock`.restaurant_id = restaurant.id 
WHERE restaurant.id = 2; -- 1 / 3

-- displays the ingredients needed for a pizza

SELECT ingredient.name as ingredients, `(assoc) composition`.quantity as quantity, pizza.name as pizza
FROM `(assoc) composition` 
INNER JOIN ingredient 
    ON `(assoc) composition`.ingredient_id = ingredient.id 
INNER JOIN pizza 
    ON `(assoc) composition`.pizza_id = pizza.id 
WHERE pizza.id = 2; -- 1 / 3 / 4 / 5 / 6

-- displays the address the name and the telephone of the customer corresponding to xxx order

SELECT client.first_name, client.name, address.address, address.complement_1, address.postal_code, address.city, phone.number, `order`.order_num
FROM client 
INNER JOIN address 
    ON client.delivery_address_id = address.id
INNER JOIN phone
    ON client.phone_id = phone.id
INNER JOIN `order` 
    ON client.id = `order`.client_id
WHERE client.id = 2; -- 1 / 3 / 4 / 5 

-- shows which employee takes care of which order 

SELECT employee.first_name, employee.name, phone.number, `order`.order_num
FROM employee 
INNER JOIN phone
    ON employee.phone_id = phone.id
INNER JOIN `order` 
    ON employee.id = `order`.employee_id
WHERE employee.id = 2; -- 1 / 3 / 4 

-- displays the invoice and customer information

SELECT `order`.order_num, bill.date, bill.all_taxe_price,  bill.payment_type, client.first_name, client.name, address.address, address.complement_1, address.postal_code, address.city
FROM `order` 
INNER JOIN address 
    ON `order`.client_id = address.id
INNER JOIN bill
    ON `order`.id = bill.order_id
INNER JOIN client 
    ON `order`.id = client.id
WHERE client.id = 2; -- 1 / 3 / 4 / 5 